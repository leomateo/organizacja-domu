# Organizacja Domu – Aplikacja Webowa

Prosta aplikacja do zarządzania domowymi obowiązkami, zakupami i przypomnieniami.

## Jak uruchomić aplikację na GitHub Pages

1. Wejdź na https://github.com i stwórz nowe repozytorium (np. `organizacja-domu`).
2. Wgraj zawartość tego ZIP-a do repozytorium (index.html i data.json).
3. Przejdź do ustawień repozytorium -> zakładka **Pages**.
4. Wybierz źródło jako **branch `main` i folder `/ (root)`**.
5. Kliknij "Save".
6. Po chwili aplikacja będzie dostępna pod adresem:  
   `https://twoja-nazwa.github.io/organizacja-domu/`

## Jak dodać aplikację do ekranu głównego na iPhonie
1. Otwórz link do aplikacji w Safari.
2. Kliknij przycisk udostępniania.
3. Wybierz **„Dodaj do ekranu początkowego”**.